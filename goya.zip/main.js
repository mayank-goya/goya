
require(['js/modules'],
    function() {
        angular.bootstrap(document, ['app','ngTouch']);
    }
);